# Aventura de Palabras - servidor local + finestra del joc
$ErrorActionPreference = 'Continue'
$www = Join-Path $PSScriptRoot 'www'
$browserProfile = Join-Path $env:LOCALAPPDATA 'AventuraPalabrasBrowser'

# cerca port lliure entre 8765 i 8794
$listener = $null; $port = 0
for ($p = 8765; $p -lt 8795; $p++) {
  $l = New-Object System.Net.HttpListener
  try {
    $l.Prefixes.Add("http://localhost:$p/")
    $l.Start()
    $listener = $l; $port = $p
    break
  } catch {
    try { $l.Close() } catch {}
  }
}
if (-not $listener) { Write-Host 'Error: cap port disponible'; exit 1 }
$url = "http://localhost:$port/index.html"
Write-Host ('Joc iniciat a ' + $url + '  (tanca aquesta finestra per aturar-lo)')

# navegador: Chrome > Edge (finestra independent mode app)
$browser = $null
$candidates = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
foreach ($c in $candidates) { if (Test-Path $c) { $browser = $c; break } }

$proc = $null
if ($browser) {
  $proc = Start-Process -FilePath $browser `
    -ArgumentList "--app=$url", "--user-data-dir=`"$browserProfile`"", '--no-first-run' -PassThru
} else {
  Start-Process $url   # navegador per defecte (obri pestanya normal)
}

$mime = @{
  '.html' = 'text/html; charset=utf-8'
  '.css'  = 'text/css'
  '.js'   = 'application/javascript'
  '.json' = 'application/json'
  '.png'  = 'image/png'
  '.svg'  = 'image/svg+xml'
  '.ico'  = 'image/x-icon'
  '.webp' = 'image/webp'
  '.txt'  = 'text/plain'
  '.woff' = 'font/woff'
  '.woff2'= 'font/woff2'
  '.webmanifest' = 'application/manifest+json'
}

$wwwFull = [IO.Path]::GetFullPath($www)
try {
  while ($listener.IsListening) {
    $ar = $listener.BeginGetContext($null, $null)
    while (-not $ar.AsyncWaitHandle.WaitOne(400)) {
      if ($proc -and $proc.HasExited) { break }   # si es tanca el navegador, parem
    }
    if ($proc -and $proc.HasExited) { break }
    if (-not $ar.IsCompleted) { continue }
    $ctx = $listener.EndGetContext($ar)
    try {
      $path = $ctx.Request.Url.LocalPath
      if ($path -eq '/') { $path = '/index.html' }
      $file = Join-Path $wwwFull ($path.Substring(1) -replace '/', '\')
      $fileFull = [IO.Path]::GetFullPath($file)
      if ($fileFull.StartsWith($wwwFull) -and (Test-Path $fileFull -PathType Leaf)) {
        $bytes = [IO.File]::ReadAllBytes($fileFull)
        $ext = [IO.Path]::GetExtension($fileFull).ToLower()
        if ($mime.ContainsKey($ext)) { $ctx.Response.ContentType = $mime[$ext] }
        else { $ctx.Response.ContentType = 'application/octet-stream' }
        $ctx.Response.ContentLength64 = $bytes.Length
        $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
      } else {
        $ctx.Response.StatusCode = 404
      }
    } catch {}
    $ctx.Response.Close()
  }
} finally {
  try { $listener.Stop(); $listener.Close() } catch {}
  Write-Host 'Servidor aturat. Fins aviat!'
}
