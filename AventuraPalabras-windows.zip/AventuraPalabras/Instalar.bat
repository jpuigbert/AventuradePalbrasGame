@echo off
echo Instal·lando Aventura de Palabras...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0crear-atajo.ps1"
echo.
echo Listo! Busca "Aventura de Palabras" en el Menu Inicio o en el Escritorio.
pause
