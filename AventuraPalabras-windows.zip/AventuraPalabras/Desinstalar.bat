@echo off
echo Desinstalando Aventura de Palabras (los progresos guardados no se borran)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Remove-Item -Recurse -Force \"$env:LOCALAPPDATA\AventuraPalabras\" -ErrorAction SilentlyContinue; Remove-Item \"$env:USERPROFILE\Desktop\Aventura de Palabras.lnk\" -ErrorAction SilentlyContinue; Remove-Item \"$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Aventura de Palabras.lnk\" -ErrorAction SilentlyContinue"
echo Listo!
pause
