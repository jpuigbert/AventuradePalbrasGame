$ErrorActionPreference = 'Stop'
$src  = $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA 'AventuraPalabras'

# copia tota la carpeta del joc
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force

$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$target  = $ps
$argline = '-NoProfile -WindowStyle Hidden -File "' + (Join-Path $dest 'servidor.ps1') + '"'
$icon    = Join-Path $dest 'www\icons\app.ico,0'

$ws = New-Object -ComObject WScript.Shell

function Make-Shortcut([string]$path) {
  $lnk = $ws.CreateShortcut($path)
  $lnk.TargetPath = $target
  $lnk.Arguments = $argline
  $lnk.WorkingDirectory = $dest
  if (Test-Path ($icon.Split(',')[0])) { $lnk.IconLocation = $icon }
  $lnk.Description = 'Juego de mesa educativo para aprender espanol'
  $lnk.Save()
}

# Escriptori
$desktop = [Environment]::GetFolderPath('Desktop')
Make-Shortcut (Join-Path $desktop 'Aventura de Palabras.lnk')

# Menú Inici (tots els usuaris no cal; només l'actual)
$start = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
Make-Shortcut (Join-Path $start 'Aventura de Palabras.lnk')

Write-Host 'Dreceres creades a l Escriptori i al Menu Inici.'
