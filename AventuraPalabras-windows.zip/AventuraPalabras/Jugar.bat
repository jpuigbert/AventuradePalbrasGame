@echo off
rem Aventura de Palabras - llancament directe
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor.ps1"
